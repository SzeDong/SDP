<?php
include("conn.php");
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="css/announcement.css">
        <title>View Timetable</title>
    </head>
    <body>
        <div>
            <h1>View Timetable</h1>
        </div>

        <table>
        <tr>
            <th>Start Time</th>
            <th>End Time</th>
            <th>Venue</th>
            <th>Club Name</th>
        </tr>
        <?php
        $sql = "SELECT * FROM timetable";
        $result = $conn->query($sql);
        
        while($data = $result->fetch_assoc()){
            echo ("<tr>");
            echo ("<td>" . $data['starttime'] . "</td>");
            echo ("<td>" . $data['endtime'] . "</td>");
            echo ("<td>" . $data['venue'] . "</td>");
            echo ("<td>" . $data['clubname'] . "</td>");
            echo ("</tr>");}
        ?>
    </table>
    <a href="hpteacher.html">
            <button class="btn">HomePage</button>
    </a>
</body>
</html>