<?php
include("conn.php");

?>

<html>
    <head>
        <title>Badminton Club Profile</title>
        <link rel="stylesheet" href="css/clubbad.css">
    </head>
    <body>
        <section class="header">
            <div class="navbar">
                <img src="css/bad.jpg" class="logo">
                <ul>
                    <li><a href="hpcommittee.html">Home</a></li>
                    <li><a href="combadclub.php">Badminton</a></li>
                    <li><a href="combkbclub.php">Basketball</a></li>
                    <li><a href="comdanclub.php">Dancing</a></li>
                    <li><a href="commedclub.php">Media</a></li>
                    <li><a href="comorcclub.php">Orchestra</a></li>
                    <li><a href="comstuclub.php">Student Council</a></li></li>
                </ul>
            </div>
            <div class="content">
                <h1>WELCOME TO BADMINTON CLUB</h1>
                <p>The Badminton Club was created for students to explore, practice and compete in the sport of badminton. Our club provides a fun, and competitive badminton environment.
                        <br>Our mission of our club is to provide the opportunity to the members to develop and improve their badminton skils.  Feel free to join us if interested!
                    </p>
                <a href="#clubpictures">
                    <button type="button"><span></span>LEARN MORE</button>
                </a>
            </div>
        </div>
    </section>
    <section class="clubpictures" id="clubpictures">
        <h1>Club Pictures</h1>
        <p>Some Memories in Badminton Club</p>
        <div class="row">
            <div class="clubpic-col">
                <h3>Our Badminton Club Photo</h3>
                <img src="css/badmintonphoto.jpg" alt="">
                <p>The Badminton Team represented in the Competition.</p>
            </div>
            <div class="clubpic-col">
                <h3>Hierachy Chart Photo</h3>
                <img src="css/badmintonclub_hierarchy.jpg" alt="">
                <p>Our Members who are responsible of leading the club.</p>
            </div>
        </div>
    </section>
    <section class="Upcoming-events">
        <h1>Upcoming Events</h1>
        <table>
            <tr>
                <th>Event Name</th>
                <th>Event Description</th>
                <th>Time</th>
                <th>Date</th>
                <th>Venue</th>
            </tr>
            <?php
            $sql = "SELECT * FROM event WHERE OrganisingClub LIKE 'Badminton Club' AND Status = 'Approved'";
            $result = $conn->query($sql);
                        
            while($data = $result->fetch_assoc()){
                echo ("<tr>");
                echo ("<td>" . $data['EventName'] . "</td>");
                echo ("<td>" . $data['EventDescription'] . "</td>");
                echo ("<td>" . $data['Time'] . "</td>");
                echo ("<td>" . $data['Date'] . "</td>");
                echo ("<td>" . $data['Venue'] . "</td>");
                echo ("</tr>");}
            ?>
        </section>
        </div>
    </body>
</html>