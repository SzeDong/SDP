<?php
    require "conn.php";
$result = mysqli_query($conn,"SELECT * FROM users");
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/clubmemberlist.css">
</head>
    <body>
        <title>View Dancing Club Member List</title>
        <h1>View Dancing Club Member List</h1>
        <div class="container">
            <table>
                <tr>
                    <th>MemberID</th>
                    <th>Name</th>
                </tr>
                <?php
            $sql = "SELECT * FROM dancingmemberlist";
            $result = $conn->query($sql);
            
            while($data = $result->fetch_assoc()){
                echo ("<tr>");
                echo ("<td>" . $data['MemberID'] . "</td>");
                echo ("<td>" . $data['MemberName'] . "</td>");
                echo ("</tr>");}
                ?>
            </table>
            <a href="adminviewclublist.php">
                <button type="button">Return</button>
            </a>
            <a href="hpadmin.html">
                <button type="button">Home</button>
            </a>
        </div>
    </body>
</html>