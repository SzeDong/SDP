<?php
	header('location:indexprofile.php')
?>