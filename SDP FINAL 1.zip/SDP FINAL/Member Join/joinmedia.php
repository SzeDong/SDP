
<!DOCTYPE html>
<html>
    <head>
        <title>Join Media Club</title>
    </head>
    <body>
        <a href="joinclub.php">Return</a>
        <a href="#">Home</a>
        <form action ="joinmedia2.php" method ="post">
            <h1>Media Club Form</h1>
            <label>Name</label> <br> <input type="text" name="MemberName" placeholder="Enter your Name" required/>
            <br><button name="submit" type="submit">Join</button>
        </form>
    </body>
</html>
