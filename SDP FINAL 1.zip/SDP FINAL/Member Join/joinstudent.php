
<!DOCTYPE html>
<html>
    <head>
        <title>Join Student Council Club</title>
    </head>
    <body>
        <a href="joinclub.php">Return</a>
        <a href="#">Home</a>
        <form action ="joinstudent2.php" method ="post">
            <h1>Student Council Club Form</h1>
            <label>Name</label> <br> <input type="text" name="MemberName" placeholder="Enter your Name" required/>
            <br><button name="submit" type="submit">Join</button>
        </form>
    </body>
</html>