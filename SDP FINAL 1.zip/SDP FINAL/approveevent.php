<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8"/>
        <meta name= "viewport" content="width=device-width, initial-scale=1.0"/>
		<link rel="stylesheet" href="css/viewclub.css">
        <title>Approve Event</title>
    </head>
    <body>
        <h1>Approve Event</h1>
		
        <div>
			<table>
				<thead>
					<th>Event Name</th>
					<th>Event Description</th>
					<th>Time</th>
					<th>Date</th>
					<th>Venue</th>
					<th>Organising Club</th>
					<th>Action</th>
					<th></th>
				</thead>
				<tbody>
					<?php
					include 'conn.php';
					
					$sql=mysqli_query($conn,"select * from event where Status='Unapproved';");
					while($row=mysqli_fetch_array($sql)){
						?>
						<tr>
							<td><?php echo $row['EventName']; ?></td>
							<td><?php echo $row['EventDescription']; ?></td>
                            <td><?php echo $row['Time']; ?></td>
                            <td><?php echo $row['Date']; ?></td>
                            <td><?php echo $row['Venue']; ?></td>
							<td><?php echo $row['OrganisingClub']; ?></td>
							<td>
								<a href="approveevent2.php?ID=<?php echo $row['EventID']; ?>">Approve</a>
								<a href="approveevent3.php?ID=<?php echo $row['EventID']; ?>">Unapprove</a>
							</td>
							
						</tr>
						<?php
					}
					?>
			</tbody>
		</table>
		<a href="hpadmin.html">
			<button type="button">Home</button>
		</a>
	</div>
    </body>
</html>