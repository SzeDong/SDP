<?php
session_start();

if(isset($_POST['login'])){
	$password = $_POST['password'];
	$password = md5($password);
	
	if($password == $_SESSION['password']){

		echo "<script>alert('Login Successfully!'); window.location='../userProfile.php';</script>";
		exit();
	}else{
		echo "<script>alert('Invalid username or password');window.location='../indexprofile.php';</script>";
		exit();
	}
}

?>