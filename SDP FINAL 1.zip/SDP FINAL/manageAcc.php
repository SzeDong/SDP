<?php
    require "conn.php";
$result = mysqli_query($conn,"SELECT * FROM users");
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" href="css/viewclub.css">
		<title>Delete Account data</title>
	</head>
	<body>
		<h1>Manage Account</h1>
		<table> 
			<tr>
				<th>Role</th>
				<th>Username</th>
				<th>Password</th>
				<th>Email</th>
				<th>Action</th>
			</tr>
			<?php
				$i=0;
				while($row = mysqli_fetch_array($result)) {
					?>
				<tr class="<?php if(isset($classname)) echo $classname;?>">
					<td><?php echo $row["role"]; ?></td>
					<td><?php echo $row["username"]; ?></td>
					<td><?php echo $row["password"]; ?></td>
					<td><?php echo $row["email"]; ?></td>
				<td>
					<a href="delete-process.php?id=<?php echo $row["id"]; ?>">Delete</a>
					<a href="updateAcc-process.php?id=<?php echo $row["id"]; ?>">Update</a>
				</td>
			</tr>
			<?php
				$i++;
			}
			?>
		</table>
		<a href="hpadmin.html">
			<button type="button">Home</button>
		</a>
	</body>
</html>