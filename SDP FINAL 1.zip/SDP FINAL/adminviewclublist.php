<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/adminclublist.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
</head>
<body>
<section>
    <div class="container">
        <div class="row"></div>
            <div class="section-title">
                <h2>View Club and Member List</h2>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="service-item padd-15">
            <div class="service-item-inner">
                <div class="icon">
                    <a href="orchestraclub2.php"><i class="fa fa-drum"></i></a>
                </div>
                <h4>Orchestra</h4>
            </div>
        </div>
        <div class="service-item padd-15">
            <div class="service-item-inner">
                <div class="icon">
                    <a href="badmintonclub2.php"><i class="fa fa-laptop-code"></i></a>
                </div>
                <h4>Badminton</h4>
            </div>
        </div>
        <div class="service-item padd-15">
            <div class="service-item-inner">
                <div class="icon">
                    <a href="basketballclub2.php"><i class="fa fa-basketball"></i></a>
                </div>
                <h4>Basketball</h4>
            </div>
        </div>
        <div class="service-item padd-15">
            <div class="service-item-inner">
                <div class="icon">
                    <a href="mediaclub2.php"><i class="fa fa-camera"></i></a>
                </div>
                <h4>Media</h4>
            </div>
        </div>
        <div class="service-item padd-15">
            <div class="service-item-inner">
                <div class="icon">
                    <a href="dancingclub2.php"><i class="fa fa-music"></i></a>
                </div>
                <h4>Dance</h4>
            </div>
        </div>
        <div class="service-item padd-15">
            <div class="service-item-inner">
                <div class="icon">
                    <a href="studentcouncilclub2.php"><i class="fa fa-user-tie"></i></a>
                </div>
                <h4>Student Council</h4>
            </div>
        </div>
    </div>
    </section>
</body>
</html>