<?php
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "sdp";

// Create connection
$conn = mysqli_connect($servername, $db_username, $db_password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

?>