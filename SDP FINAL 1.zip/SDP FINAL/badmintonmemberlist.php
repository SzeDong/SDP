<?php
    include("conn.php");
    ?>
<!DOCTYPE html>

<html>
    <head>
        <title>Badminton Club Member List</title>
        <link rel="stylesheet" href="css/memberlist.css">
    </head>
    
    <body>
        <button onclick="window.history.back()">Go Back</button>
        <div class="header">
            <p>Badminton Club Member List</p>
        </div>
        
    </div>
    <div class="container">
        <div class="search_wrap">
        <form method = "post">
            <input type="text" name="badmintonmember" placeholder="Search for member's ID or Name" size= "30" required/>
            <input type ="submit" name="searchname" value="SEARCH"/><br><br>
        </form>
        </div>
    </div>
    <section class="MemberTable">
        <table>
            <tr>
                <th>MemberID</th>
                <th>Name</th>
            </tr>
            <?php
                    $sql = "SELECT * FROM badmintonmemberlist";
                    $result = $conn->query($sql);
                    
                    while($data = $result-> fetch_assoc()){
                        echo ("<tr>");
                        echo ("<td>" . $data['MemberID'] . "</td>");
                        echo ("<td>" . $data['MemberName'] . "</td>");
                        echo ("</tr>");}
                        ?>
            </table>
        </section>
        <section class="SearchTable">
            <h2>Result of search</h2>
            <table>
                <tr>
                    <th>MemberID</th>
                    <th>Name</th>
                </tr>
                <?php 
            if(isset($_POST['searchname'])){
                require "badmintonsearch.php";
                if(count($results)> 0){
                    foreach ($results as $r){
                        echo ("<tr>");
                        echo ("<td>" . $r['MemberID'] . "</td>");
                        echo ("<td>" . $r['MemberName'] . "</td>");
                        echo ("<tr>");
                    }
                }else{echo "<div> No result found</div>";}
            }
            ?>
            </table>
        </section>
    </body>
    </html>