<?php
include("conn.php");
?>

<!DOCTYPE html>
<html>
<style>
    .announcement button[type="addbtn"]{
    background-color: #F10758;
    color: white;
    padding: 16px;
    font-size: 13px;
    border: none;
    }
</style>

    <head>
        <link rel="stylesheet" href="css/announcement.css">
        <title>View Announcement</title>
    </head>
    <body>

    <div>
        <h1>View Announcement</h1>
    </div>

    <div class = announcement>
        <form action="addannouncement.php">
        <button type="addbtn">Add Announcement</button>
        </form>
    </div>

        <table>
        <tr>
            <th>Club Name</th>
            <th>Announcement Description</th>
        </tr>
        <?php
        $sql = "SELECT * FROM newannouncement";
        $result = $conn->query($sql);
        
        while($data = $result->fetch_assoc()){
            echo ("<tr>");
            echo ("<td>" . $data['clubname'] . "</td>");
            echo ("<td>" . $data['announcementdescription'] . "</td>");
            echo ("</tr>");}
        ?>
    </table>
    <a href="hpteacher.html">
            <button class="btn">HomePage</button>
    </a>
</body>
</html>