<!DOCTYPE html>
<html>
    <head>
        <title>Join Basketball Club</title>
        <link rel="stylesheet" href="css/joinclub.css">
    </head>
    <body>
        <div class="container">
            <a href="bkbclubmember.php">Return</a>
            <a href="hpmember.html">Home</a>
            <form action ="joinbasketball2.php" method ="post">
                <div class="input-box">
                    <h1>Basketball Club Form</h1>
                    <input type="text" name="MemberName" placeholder="Enter your Name" required/>
                </div>
                <br><button name="submit" type="submit" class="btn">Join</button>
            </form>
        </div>
    </body>
</html>