<?php
include("conn.php");
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="css/announcement.css">
        <title>View Announcement</title>
    </head>
    <body>
        <div>
            <h1>View Announcement</h1>
        </div>
        <table>
        <tr>
            <th>Club Name</th>
            <th>Announcement Description</th>
        </tr>
        <?php
        $sql = "SELECT * FROM newannouncement";
        $result = $conn->query($sql);
        
        while($data = $result->fetch_assoc()){
            echo ("<tr>");
            echo ("<td>" . $data['clubname'] . "</td>");
            echo ("<td>" . $data['announcementdescription'] . "</td>");
            echo ("</tr>");}
        ?>
        </table>
        <a href="hpmember.html">
            <button class="btn">HomePage</button>
        </a>
</body>
</html>